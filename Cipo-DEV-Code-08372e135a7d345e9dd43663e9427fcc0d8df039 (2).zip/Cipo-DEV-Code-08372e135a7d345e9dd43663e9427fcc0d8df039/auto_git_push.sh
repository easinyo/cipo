# Git: add and commit changes
cd /home/tarek/ipv_siewling/ipv && /usr/bin/git commit -a -m "weekly crontab code update `date`"

# send data to Git server
cd /home/tarek/ipv_siewling/ipv && /usr/bin/git push origin master
