#!/bin/bash


pip install --upgrade pip
sudo apt-get install python-pip
sudo apt-get install libsasl2-dev
pip install thrift==0.9.3
pip install impyla
#pip install pyhs2
pip install pyarrow
pip install beautifulsoup4
pip install lxml
pip install requests
pip install wget
pip install retrying
pip install selenium
pip install pysocks
pip install python_anticaptcha
pip install Cython
pip install pyarrow==0.7.0
pip install pysftp
sudo apt-get install unzip
pip install pandas
